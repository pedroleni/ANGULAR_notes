import { Component, inject } from '@angular/core';
import { UsuariosService } from '../services/usuarios.service';
import { UsuariosComponent } from '../components/usuarios.component';

@Component({
  selector: 'usuario-page',
  standalone: true,
  imports: [UsuariosComponent],
  providers: [UsuariosService],
  template: ` <app-usuarios></app-usuarios> `,
})
export class UsuariosPageComponent {
  // Rename to avoid selector/class name conflict
  contador = inject(UsuariosService);
}
