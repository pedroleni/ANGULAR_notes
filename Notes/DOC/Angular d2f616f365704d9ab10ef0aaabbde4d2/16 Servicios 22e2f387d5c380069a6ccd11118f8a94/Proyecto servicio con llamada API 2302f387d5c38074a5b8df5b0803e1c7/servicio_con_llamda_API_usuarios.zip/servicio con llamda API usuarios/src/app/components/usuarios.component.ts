import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';
import { UsuariosService } from '../services/usuarios.service';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  providers: [UsuariosService],
  template: `
    <h2>Lista de usuarios</h2>

    @if (loading) {
    <p>Cargando usuarios...</p>
    } @else { @if (error) {
    <p style="color:red;">Error al cargar usuarios</p>
    } @else {
    <ul>
      @for (usuario of usuarios; track usuario.id) {
      <li>{{ usuario.name }} - {{ usuario.email }}</li>
      } @empty {
      <li>No hay usuarios disponibles</li>
      }
    </ul>
    } }
  `,
})
export class UsuariosComponent implements OnInit {
  private usuariosService = inject(UsuariosService);

  usuarios: any[] = [];
  loading = true;
  error = false;

  ngOnInit() {
    this.usuariosService.getUsuarios().subscribe({
      next: (data) => {
        this.usuarios = data;
        this.loading = false;
      },
      error: () => {
        this.error = true;
        this.loading = false;
      },
    });
  }
}
