import { UsuariosPageComponent } from './pages/usuarios-page.component';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  imports: [UsuariosPageComponent],
  template: '<usuario-page></usuario-page>',
  styleUrl: './app.css',
})
export class App {}
