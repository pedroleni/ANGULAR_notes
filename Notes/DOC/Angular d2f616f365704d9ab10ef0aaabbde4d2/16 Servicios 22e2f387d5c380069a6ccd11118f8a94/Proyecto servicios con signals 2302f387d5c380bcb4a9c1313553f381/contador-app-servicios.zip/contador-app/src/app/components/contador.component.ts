import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContadorService } from '../services/contador.service';

@Component({
  selector: 'app-contador',
  standalone: true,
  imports: [CommonModule],
  providers: [ContadorService],
  template: `
    <h2>Contador: {{ contador.valor() }}</h2>
    <button (click)="contador.incrementar()">Incrementar</button>
    <button (click)="contador.reiniciar()">Reiniciar</button>
  `,
})
export class ContadorComponent {
  contador = inject(ContadorService);
}
