import { Component, signal } from '@angular/core';
import { ContadorPageComponent } from './pages/contador-page.component';

@Component({
  selector: 'app-root',
  imports: [ContadorPageComponent],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly title = signal('contador-app');
}
