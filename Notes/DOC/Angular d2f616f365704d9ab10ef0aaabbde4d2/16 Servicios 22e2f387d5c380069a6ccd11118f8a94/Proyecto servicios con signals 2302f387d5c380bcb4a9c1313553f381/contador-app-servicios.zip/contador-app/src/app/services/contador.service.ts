import { Injectable, signal } from '@angular/core';

@Injectable()
export class ContadorService {
  private _valor = signal(0);
  readonly valor = this._valor.asReadonly();

  incrementar() {
    this._valor.update((v) => v + 1);
  }

  reiniciar() {
    this._valor.set(0);
  }
}
