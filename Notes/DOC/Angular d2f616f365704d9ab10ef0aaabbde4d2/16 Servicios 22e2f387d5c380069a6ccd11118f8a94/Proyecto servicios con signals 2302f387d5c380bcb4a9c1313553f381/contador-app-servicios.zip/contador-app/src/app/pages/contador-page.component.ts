import { Component, inject } from '@angular/core';
import { ContadorService } from '../services/contador.service';
import { ContadorComponent } from '../components/contador.component';

@Component({
  selector: 'contador-page',
  standalone: true,
  imports: [ContadorComponent],
  providers: [ContadorService],
  template: ` <app-contador></app-contador> `,
})
export class ContadorPageComponent {
  // Rename to avoid selector/class name conflict
  contador = inject(ContadorService);
}
