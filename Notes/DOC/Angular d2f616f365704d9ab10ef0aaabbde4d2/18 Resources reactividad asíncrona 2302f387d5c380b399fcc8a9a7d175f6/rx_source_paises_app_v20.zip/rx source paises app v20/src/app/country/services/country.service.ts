import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

import { RESTCountry } from '../interfaces/rest-countries.interface';
import { map, Observable, catchError, throwError, delay, of, tap } from 'rxjs';
import type { Country } from '../interfaces/country.interface';
import { CountryMapper } from '../mappers/country.mapper';
import { Region } from '../interfaces/region.type';

const API_URL = 'https://restcountries.com/v3.1';

@Injectable({
  providedIn: 'root',
})
export class CountryService {
  private http = inject(HttpClient);
  // cache para evitar múltiples peticiones al mismo endpoint
  // y mejorar el rendimiento de la aplicación

  private queryCacheCapital = new Map<string, Country[]>();
  private queryCacheCountry = new Map<string, Country[]>();
  private queryCacheRegion = new Map<Region, Country[]>();

  //!------------------------------------------------------------------------------
  //?------------------------BUSCAR POR CAPITAL------------------------------------
  //!------------------------------------------------------------------------------

  searchByCapital(query: string): Observable<Country[]> {
    query = query.toLowerCase();

    if (this.queryCacheCapital.has(query)) {
      /**
       * Si el query ya existe en el cache, retornamos el valor
       * el of crea un observable que emite el valor
       * y luego completa, sin necesidad de hacer una petición HTTP
       * esto mejora el rendimiento de la aplicación
       * y evita múltiples peticiones al mismo endpoint
       */
      return of(this.queryCacheCapital.get(query) ?? []);
    }

    return this.http.get<RESTCountry[]>(`${API_URL}/capital/${query}`).pipe(
      map((resp) => CountryMapper.mapRestCountryArrayToCountryArray(resp)),
      tap((countries) => this.queryCacheCapital.set(query, countries)),
      catchError((err) => {
        // Aquí puedes personalizar el error si quieres
        return throwError(
          () => new Error('No se pudo cargar la información del país')
        );
      })
    );
  }

  //!------------------------------------------------------------------------------
  //?------------------------BUSCAR POR PAIS------------------------------------
  //!------------------------------------------------------------------------------
  searchByCountry(query: string) {
    const url = `${API_URL}/name/${query}`;
    query = query.toLowerCase();

    if (this.queryCacheCountry.has(query)) {
      return of(this.queryCacheCountry.get(query) ?? []);
    }
    /**
     * Realizamos una petición HTTP al endpoint de países
     * y mapeamos la respuesta a un array de Country
     * utilizando el CountryMapper
     * luego guardamos el resultado en el cache
     * para evitar múltiples peticiones al mismo endpoint
     * y mejorar el rendimiento de la aplicación
     * además, agregamos un delay de 2 segundos para simular una carga
     * y mejorar la experiencia del usuario
     * si ocurre un error, lo capturamos y retornamos un error
     * personalizado con el mensaje de error
     * que se puede manejar en el componente que llama a este servicio
     */
    return this.http.get<RESTCountry[]>(url).pipe(
      map((resp) => CountryMapper.mapRestCountryArrayToCountryArray(resp)),
      tap((countries) => this.queryCacheCountry.set(query, countries)),
      //delay(2000),
      catchError((error) => {
        console.log('Error fetching ', error);

        return throwError(
          () => new Error(`No se pudo obtener países con ese query ${query}`)
        );
      })
    );
  }
  //!------------------------------------------------------------------------------
  //?------------------------BUSCAR POR REGION------------------------------------
  //!------------------------------------------------------------------------------
  searchByRegion(region: Region) {
    const url = `${API_URL}/region/${region}`;

    if (this.queryCacheCountry.has(region)) {
      return of(this.queryCacheCountry.get(region) ?? []);
    }

    return this.http.get<RESTCountry[]>(url).pipe(
      map((resp) => CountryMapper.mapRestCountryArrayToCountryArray(resp)),
      tap((countries) => this.queryCacheRegion.set(region, countries)),
      catchError((error) => {
        console.log('Error fetching ', error);

        return throwError(
          () => new Error(`No se pudo obtener países con ese query ${region}`)
        );
      })
    );
  }
  //!------------------------------------------------------------------------------
  //?------------------------BUSCAR POR SIGLAS------------------------------------
  //!------------------------------------------------------------------------------
  searchCountryByAlphaCode(code: string) {
    const url = `${API_URL}/alpha/${code}`;

    return this.http.get<RESTCountry[]>(url).pipe(
      map((resp) => CountryMapper.mapRestCountryArrayToCountryArray(resp)),
      /**
       * Si la respuesta es un array con un solo elemento,
       * retornamos ese elemento como un Observable de Country
       * si no, retornamos undefined
       * esto es útil para cuando se busca un país por su código
       * y se espera que la respuesta sea un único país
       * si ocurre un error, lo capturamos y retornamos un error
       * personalizado con el mensaje de error
       */
      map((countries) => countries.at(0)),
      catchError((error) => {
        console.log('Error fetching ', error);

        return throwError(
          () => new Error(`No se pudo obtener países con ese código ${code}`)
        );
      })
    );
  }
}
