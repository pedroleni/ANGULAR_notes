import { Component, computed, effect, input, ResourceRef } from '@angular/core';
import { Country } from '../../interfaces/country.interface';
import { DecimalPipe, JsonPipe } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'country-list',
  imports: [DecimalPipe, RouterLink],
  templateUrl: './country-list.component.html',
})
export class CountryListComponent {
  countries = input.required<ResourceRef<Country[] | undefined>>();
}
