import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-pruebas',
  standalone: true,
  imports: [ CommonModule],
  templateUrl: './pruebas.component.html',
  styleUrl: './pruebas.component.css'
})
export class PruebasComponent {
   welcome: String  = "Bienvenido a nuestra primera pagina de angular"
  tasks : String[] =[
    'Apreder angular',
    'Probar angular',
    'Probar cli',
    'Lanzar el servidor de angular'
  ]

}
